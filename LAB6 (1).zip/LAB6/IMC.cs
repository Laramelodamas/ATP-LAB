﻿namespace LAB6;

class Program
{
    static void Main(string[] args)
    {
        //declaração de variáveis
        double peso, alt, imc;

        //entrada de dados
        Console.WriteLine("Digite seu peso e sua altura em quilogramas e metros, respectivamente:");
        peso = double.Parse(Console.ReadLine()!);
        alt = double.Parse(Console.ReadLine()!);

        //Processamento
        imc = peso / (Math.Pow(alt, 2));

        switch(imc){
            case > 34:
                Console.WriteLine("Muito Obeso");
                break;
            case >= 30:
                Console.WriteLine("Obeso");
                break;
            case >= 25:
                Console.WriteLine("Acima do Peso");
                break;
            case >= 20:
                Console.WriteLine("Peso Normal");
                break;
            default:
                Console.WriteLine("Abaixo do Peso");
                break;
        }
    }
}
